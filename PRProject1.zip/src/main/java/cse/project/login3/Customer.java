
package cse.project.login3;

public class Customer extends User {
       public Customer(){
        loginBehavior = new Customer_Login();

    }
    
    public void display() {
     System.out.println("고객");
    }

}

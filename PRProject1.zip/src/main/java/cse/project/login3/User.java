
package cse.project.login3;

import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public abstract class User {
    Login_Behavior loginBehavior;   
   
   protected JTextField id;
   protected JPasswordField pw;
   protected JRadioButton t;
  
  public User(){
      
  }
  
  public abstract void display() ;

  public void performLogin(JTextField id,JPasswordField pw, JRadioButton t) {
  // JTextField id1 = null;
  // JPasswordField pw1 = null;
  // JRadioButton type2 = null;
   
    loginBehavior.login(id, pw, t);
  }

//  public void performLogin_customer() {
 //     loginBehavior.login();
  //}
  
 //public void setLogin(Login_Behavior lb)
 //{
   //  loginBehavior =lb;
     
 //}
 
public void login_user(){
    System.out.println("로그인을 합니다");
    
}


}

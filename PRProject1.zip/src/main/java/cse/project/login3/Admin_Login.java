
package cse.project.login3;

import cse.project.user_management02.Admin_MainFrame;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Admin_Login implements Login_Behavior {

  //  private JTextField id;
  //  private JPasswordField pw;
  private  JRadioButton type2;
  Connection conn=null;
  PreparedStatement pst=null;
 ResultSet rs=null;
    
  //Login_mainframe frame =new Login_mainframe();
 //  protected JRadioButton type;
   
    public void login(/*String id, String pw, String type*/JTextField id, JPasswordField pw, JRadioButton type2) {
  
     // Login_mainframe frame =new Login_mainframe();
     // frame.LoginAdmin();
      // JRadioButton type2 =  type;
       if(type2.isSelected()){
        String sql="Select * from admin_login.login where ID=? and Password=?";       
        try{
            
            String url = "jdbc:mysql://localhost:3306/admin_login?serverTimezone=UTC";
            conn = DriverManager.getConnection(url, "root", "dusdj9907A!");
                          
             PreparedStatement pst=conn.prepareStatement(sql);    
             pst.setString(1,id.getText());
             pst.setString(2,pw.getText());
             ResultSet rs= pst.executeQuery();
            if(rs.next()){
              JOptionPane.showMessageDialog(null,"환영합니다");        
              System.out.println("관리자 로그인 성공");
              Admin_MainFrame main = new Admin_MainFrame();
               main.setVisible(true);     
              
              main.pack();
              main.setLocationRelativeTo(null);
              main.setExtendedState(JFrame.MAXIMIZED_BOTH);
            }  
        else{
             JOptionPane.showMessageDialog(null,"로그인 에러");
             System.out.println("로그인 실패");            
            // r.setVisible(true);             
        }
          
    }  catch (SQLException ex) {
         JOptionPane.showMessageDialog(null,ex);
     
    
    }
  }

    }
}
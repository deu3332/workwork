
package cse.project.login3;

import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public interface Login_Behavior {            //인터페이스
 public void login(/*String id, String pw, String type*/JTextField id, JPasswordField pw,JRadioButton t) ;
 
 

}

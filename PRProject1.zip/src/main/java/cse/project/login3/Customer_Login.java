
package cse.project.login3;

import cse.project.user_management02.Admin_MainFrame;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Customer_Login implements Login_Behavior {
  // Login_mainframe frame =new Login_mainframe();
   private  JRadioButton type1;
   Connection conn=null;
   PreparedStatement pst=null;
   ResultSet rs=null;

   public void login(/*String id, String pw, String type*/JTextField id, JPasswordField pw, JRadioButton type1) {
  

      if(type1.isSelected()){
        String sql="Select * from customer_login.login where ID=? and Password=?";       
        try{
            
            String url = "jdbc:mysql://localhost:3306/customer_login?serverTimezone=UTC";
            conn = DriverManager.getConnection(url, "root", "dusdj9907A!");
                          
             PreparedStatement pst=conn.prepareStatement(sql);    
             pst.setString(1,id.getText());
             pst.setString(2,pw.getText());
             ResultSet rs= pst.executeQuery();
            if(rs.next()){
              JOptionPane.showMessageDialog(null,"환영합니다");        
              System.out.println("고객 로그인 성공");
             
              String status="1";
            
            }  
        else{
             JOptionPane.showMessageDialog(null,"로그인 에러");
             System.out.println("로그인 실패");            
                         

// r.setVisible(true);             
        }
          
    }  catch (SQLException ex) {
         JOptionPane.showMessageDialog(null,ex);
     
    
    }
    //  Login_mainframe f =new Login_mainframe();
    //  f.LoginCustomer();

    }

}
}

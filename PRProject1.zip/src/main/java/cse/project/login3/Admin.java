
package cse.project.login3;

public class Admin extends User {
    public Admin(){
        loginBehavior = new Admin_Login();

    }
    
    
    
  public void display() {
      System.out.println("관리자");
  }

}

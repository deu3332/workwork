
package cse.project.user_management02;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
public class Add_Admin implements Observer {
    /*private String id;
    private String pw;
    private String name;
    */
 //   private JTable jTable1;
    private JTextField id ;
    private JPasswordField pw;
    private JTextField name ;
    
    private Subject adminData;
    
    public Add_Admin(Subject adminData){
     this.adminData=adminData;
     adminData.addObserver(this);
     
 }
  public void update(JTable jTable1,JTextField id,JPasswordField pw,JTextField name) {
      /*this.id=id;
      this.name=name;
      this.pw=pw;
      */
     // this.jTable1=jTable1;
      this.id=id;
      this.name= name;
      this.pw=pw;
     
      add_admin(id,pw,name);
  }
  

  public void add_admin(JTextField id,JPasswordField pw,JTextField name) {  //관리자 추가 표시 display와 같은 형식?
     
   //  DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
 
       String Id =id.getText();                //id.getText();

      String Password =pw.getText();             //pw.getText();
  
      String Name1 = name.getText();                // name.getText();
     
      
     try
        {
           Class.forName("com.mysql.cj.jdbc.Driver");
           String url = "jdbc:mysql://localhost:3306/admin_login?serverTimezone=UTC";
            Connection con = (Connection) DriverManager.getConnection(url, "root", "dusdj9907A!");
            String query = "insert into admin_login.login(ID, Password, name)" + "values('"+ Id + "', '" + Password + "', '"
                    + Name1+"');";
            
                System.out.println(query);  
                Statement smt3=con.createStatement();

                       int success=smt3.executeUpdate(query);
                            if(success==1)
                            {
                                JOptionPane.showMessageDialog(null, "관리자 추가 완료");
                                System.out.println("관리자 추가");
                            }
                            else
                            {

                                JOptionPane.showMessageDialog(null, "다시 시도해주십시오.");
                                 System.out.println("관리자 추가 실패");
                            }


        }

    catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
  
  
  
  }  

}

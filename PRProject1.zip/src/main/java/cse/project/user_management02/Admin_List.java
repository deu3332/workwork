
package cse.project.user_management02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Admin_List implements Observer {
    //Add_Admin add = new Add_Admin();
   //Admin_List_Frame frame = new Admin_List_Frame();
  
  private Subject adminData; 
/*  private String id;
  private String pw;
  private String name;
  */
 private JTable jTable1;
 private JTextField id;
 private JPasswordField pw;
 private JTextField name;
 
 public Admin_List(Subject adminData){
       this.adminData= adminData;
       adminData.addObserver(this);
       
       
      //adminData.addObserver(add);
     //adminData.addObserver(this);
      //this.admindata= admindata;
       //Add_Admin add =new Add_Admin();
      
 }
  public void update(JTable jTable1,JTextField id,JPasswordField pw,JTextField name) {//업데이트 해서 admin_list 호출
     // this.id=id;
      //this.pw=pw;
      //this.name=name;
      
      this.jTable1=jTable1;
      admin_list(jTable1/*,id,pw,name*/);
      
  }

 
  
  public void admin_list(JTable jTable1/*,JTextField id,JPasswordField pw,JTextField name*/) {          //display와 같은 맥락? 현재 관리자 목록 보여줌
  
          // Add_Admin add = new Add_Admin();
           
           DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        
            try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/admin_login?serverTimezone=UTC";
            Connection con = (Connection) DriverManager.getConnection(url, "root", "dusdj9907A!");

            Statement stmt = con.createStatement();
             String query = "select * from admin_login.login";
            ResultSet rs=stmt.executeQuery(query);
            while(rs.next()) {
                String Id = rs.getString("ID");
                String Password = rs.getString("Password");
                String Name1 = rs.getString("name");
                
                System.out.println(query);
                 model.addRow(new Object[] {Id,Password,Name1});
                
                
            }
            
            rs.close();
         
           } 
           
             catch (Exception e) {
            JOptionPane.showMessageDialog(null,e.getMessage());
     
           } 
  }

}

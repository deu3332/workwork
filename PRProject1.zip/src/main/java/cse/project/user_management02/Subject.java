
package cse.project.user_management02;

public interface Subject {
    
public void addObserver(Observer o) ;
public void removeObserver(Observer o) ;
public void notifyObservers() ;

//protected  List <observer> observers;

  

}


package cse.project.user_management02;

import java.util.ArrayList;
import java.util.LinkedList;
import javax.swing.JPasswordField;
import javax.swing.JTable;
import javax.swing.JTextField;

public class AdminData implements Subject {
    private ArrayList observers;
   /* private String id;
    private String pw;
    private String name;
   */ 
    private JTable jTable1;
    private JTextField id;
    private JPasswordField pw;
    private JTextField name;
    //private String id;
   // private String pw;

    
  public void addObserver(Observer o) {
      observers.add(o);
    //  Add_Admin adminData = new Add_Admin(adminData);
     // adminData.add_admin(id,pw,name);
     // o.update(jTable1, id, pw, name);
  }

  public void removeObserver(Observer o) {
      int i=observers.indexOf(0);
      if(i>=0){
      observers.remove(i);
  }
  }
  
  public void notifyObservers() {
        for(int i=0; i<observers.size();i++){
         Observer observer =(Observer)observers.get(i);
          observer.update(jTable1,id,pw,name);
          
      }
  }

  public AdminData() {
      observers=new ArrayList();
      
  }

  public void messagechanged() {
      notifyObservers();
  }

  
  public void setMeasurements(JTable jTable1,JTextField id,JPasswordField pw,JTextField name){
      
      this.jTable1=jTable1;
      this.id=id;    
      this.name=name;
      this.pw=pw;
      
     //Admin_List list =new Admin_List();
   //  list.admin_list(jTable1);
       
  
   //   Add_Admin add = new Add_Admin();
    //   add.add_admin(id,pw,name);

      messagechanged();      
  }
  
  
  
 


}

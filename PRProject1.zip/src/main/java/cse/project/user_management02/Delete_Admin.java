
package cse.project.user_management02;
import javax.swing.JPasswordField;
import javax.swing.JTable;
import javax.swing.JTextField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;
class Delete_Admin implements Observer {
    
    private JTextField id ;
    private JPasswordField pw;
    private Subject adminData; 
    
    
    public Delete_Admin(Subject adminData){
      this.adminData=adminData;
       adminData.addObserver(this);
        
    }
    

 public void update(JTable jTable1,JTextField id,JPasswordField pw,JTextField name) {
 
  this.id=id;
  this.pw=pw;
  
  delete_admin(id,pw);

 }

 
  
  
  
  public void delete_admin(JTextField id,JPasswordField pw) {   //관리자 삭제 표시
        String Id=id.getText();
        String Password=pw.getText();
       try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/admin_login?serverTimezone=UTC";
            Connection con = (Connection) DriverManager.getConnection(url, "root", "dusdj9907A!");
            
             Statement stmt = con.createStatement();
            String query =  "delete from admin_login.login where ID='"+Id+"'&&Password='"+Password+"'";
            int success=stmt.executeUpdate(query);
                if(success==1)
                {
                    JOptionPane.showMessageDialog(null, "관리자 탈퇴 완료");
                    System.out.println("관리자 탈퇴");
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "탈퇴 오류");
                    System.out.println("관리자 탈퇴 실패");
                }

                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e.getMessage());
                    //e.printStackTrace();
                }
  
  
  
  
  
  
  
  
  
  
  }

}

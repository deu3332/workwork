
package cse.project.user_management02;

import javax.swing.JPasswordField;
import javax.swing.JTable;
import javax.swing.JTextField;

public interface Observer {
  public void update(JTable jTable1,JTextField id,JPasswordField pw,JTextField name) ;

}
